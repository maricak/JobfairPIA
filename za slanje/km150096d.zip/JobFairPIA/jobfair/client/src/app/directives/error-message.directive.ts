// import { Directive, Input, ElementRef, Renderer2, OnInit } from '@angular/core';

// @Directive({
//     selector: '[appErrorMessage]'
// })
// export class ErrorMessageDirective implements OnInit {


//     @Input('appErrorMessage') error : string;
//     // set error(value: boolean) {
//     //     console.log(value);
//     //     //this.renderer.addClass(this.element, 'bg-dark');
//     // }

//     constructor(private element: ElementRef, private renderer: Renderer2) { }

//     ngOnInit() {
//         this.renderer.addClass(this.element.nativeElement, 'bg-info');
//         this.renderer.addClass(this.element.nativeElement, 'border');
//         this.renderer.addClass(this.element.nativeElement, 'border-success');
//     }
// }
